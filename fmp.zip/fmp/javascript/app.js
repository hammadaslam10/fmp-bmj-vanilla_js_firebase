
const firebaseConfig = {
    apiKey: "AIzaSyCabd3M6jwgytfh1LPNOt11Q0knyuAS8TI",
    authDomain: "fmp-bmj.firebaseapp.com",
    databaseURL: "https://fmp-bmj-default-rtdb.firebaseio.com",
    projectId: "fmp-bmj",
    storageBucket: "fmp-bmj.appspot.com",
    messagingSenderId: "48062727158",
    appId: "1:48062727158:web:5e9a11092c1b7811b23dd7"
  };
 
  var app = firebase.initializeApp(firebaseConfig);
  shoparray=[
    {
      img:"/images/img1.jpg",
      price:"90",
    },
    {
      img:"/images/img2.jpg",
      price:"70",
    },
    {
      img:"/images/img3.jpg",
      price:"80",
    },
    {
      img:"/images/img4.jpg",
      price:"90",
    },
    {
      img:"/images/img5.jpg",
      price:"100",
    },
    {
      img:"/images/img6.jpg",
      price:"150",
    },
    {
      img:"/images/img7.jpg",
      price:"150",
    },
    {
      img:"/images/img8.jpg",
      price:"150",
    },    {
      img:"/images/img9.jpg",
      price:"150",
    },    {
      img:"/images/img10.jpg",
      price:"150",
    }
  ]
  



// function signUp2(){
//     var firstname =document.getElementById('signname').value
//     var email =document.getElementById('signemail').value
//     var phone =document.getElementById('signpass').value
//     const promise = auth.createUserWithEmailAndPassword(firstname,email,phone);
//     //
//     promise.catch(e=>alert(e.message));
//     alert("SignUp Successfully");
// }

function signup(){

    var firstname =document.getElementById('signname').value
    var email =document.getElementById('signemail').value
    var phone =document.getElementById('signpass').value
    

if(firstname.length > 0 && email.length > 0  && phone.length > 0){
    alert("done")
saveData(firstname,email,phone)
window.open("./home.html")

}
else{
    alert("fill your form completely")
    firstname.innerHTML=" "
    email.innerHTML=" "
    phone.innerHTML=" "

}
}


function saveData(namepara,emailpara,phonepara){
  app.database().ref('/').child("users").push({name:namepara,email:emailpara,pass:phonepara})
}
var id=[]
// var email=[]
// var pass=[]
// var num=[]

app.database().ref('/users').on("child_added",function(data){
  
  console.log(data.key)
  console.log(data.val())
  id.push(data.key);
  
    })
    // app.database().ref(`/todos/${id[0]}/`).on("child_added",function(data){
  
    //   // console.log(data.key)
    //   console.log(data+"                 "+"sadasda")
    //   // id.push(data.key);
      
    //     })
    function swaping(preset,replace){
      
      document.getElementById(preset).src=replace
    }
    function unswap(preset,replace){
      document.getElementById(preset).src=replace
    }
    
 var index=0
var locate=" "
var price1=0;
    function cartvalue(local){
      console.log(local)
for(var i=0;i<shoparray.length-1;i++){
  
if(shoparray[i].img==local){
  index=i
  locate=local
  shoparray[i].price=price1
 
  window.open("./cart.html")

}
}
    }
 
    function showvalue() {
      var img = document.getElementById('cartimg')
      img.src = shoparray[index].img 
      

            
    }

    function showprice(){
      var p=parseInt(shoparray[index].price)
      var price2=document.getElementById('pricetag')
     price2.innerHTML=p
    }
    function cart(){
var cartimg=document.getElementById('cartimg')
cartimg.innerHTML.src=locate
var prices=document.getElementById('pricetag')
prices.innerHTML=price1
    }
